// BOT TELE
module.exports = {
  BOT_TOKEN: "8000264460:AAHoNwtJNNUV_GAeK6h2R_rimKGmC_uxNFU", // Token bot Telegram
  OWNER_ID: "6889777508", // ID pemilik bot
  allowedGroupIds: [-1002401306074, -1002361556670, -1002386380830, -1002415460020, -4514397992], // ID grup yang diizinkan
};